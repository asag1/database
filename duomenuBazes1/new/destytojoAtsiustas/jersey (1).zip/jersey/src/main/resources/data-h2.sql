INSERT INTO person (id, firstname, lastname)
  VALUES
      (1, 'Antanas',  'Antanavičius'),
      (2, 'Vardas', 'Pavardenis'),
      (3, 'Giedrius', 'Pavardenis');