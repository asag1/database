/**
 * @author Pavel Vrublevskij
 *
 */
package lt.asprogramuoju.jersey.domain;