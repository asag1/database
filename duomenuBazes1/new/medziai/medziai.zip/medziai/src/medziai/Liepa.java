package medziai;

public class Liepa extends Lapuociai {

    public Liepa(String rusis, int metai, double aukstis, String spalva, String lapuTipas) {
        super(rusis, metai, aukstis, spalva, lapuTipas);
    }
}
