package medziai;

public class Azuolas extends Lapuociai {

    public Azuolas(String rusis, int metai, double aukstis, String spalva, String lapuTipas) {
        super(rusis, metai, aukstis, spalva, lapuTipas);
    }
}
