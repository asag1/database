package medziai;

public class Egle extends Spygliuociai {

    public Egle(String rusis, int metai, double aukstis, String spygliuTipas) {
        super(rusis, metai, aukstis, spygliuTipas);
    }
}
