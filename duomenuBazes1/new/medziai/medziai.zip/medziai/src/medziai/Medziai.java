package medziai;

interface Medziai {

    String turi();
    String kirsti();
}
