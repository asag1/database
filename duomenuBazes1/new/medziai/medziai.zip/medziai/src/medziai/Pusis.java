package medziai;

public class Pusis extends Spygliuociai {

    public Pusis(String rusis, int metai, double aukstis, String spygliuTipas) {
        super(rusis, metai, aukstis, spygliuTipas);
    }
}
