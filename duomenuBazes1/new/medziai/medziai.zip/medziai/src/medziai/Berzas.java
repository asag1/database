package medziai;

public class Berzas extends Lapuociai {

    public Berzas(String rusis, int metai, double aukstis, String spalva, String lapuTipas) {
        super(rusis, metai, aukstis, spalva, lapuTipas);
    }
}
