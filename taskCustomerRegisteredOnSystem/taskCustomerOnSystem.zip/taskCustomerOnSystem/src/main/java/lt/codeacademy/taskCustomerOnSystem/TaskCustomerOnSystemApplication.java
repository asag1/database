package lt.codeacademy.taskCustomerOnSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskCustomerOnSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskCustomerOnSystemApplication.class, args);
	}

}
